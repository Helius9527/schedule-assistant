# JLC week-schedule floating widget launcher (PowerShell + WPF, always-on-top)
# Pure ASCII content; all Chinese text lives in schedule-widget.html (UTF-8).
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$widgetPath = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\schedule-widget.html"

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Schedule" Width="1080" Height="1280"
        WindowStyle="None" Topmost="True" ResizeMode="NoResize" ShowInTaskbar="True">
  <Grid>
    <WebBrowser Name="wb" Margin="0,44,0,0"/>
    <Border Name="titleBar" Background="#2563eb" Height="44" VerticalAlignment="Top">
      <Grid>
        <TextBlock Text="Week Schedule" Foreground="White" VerticalAlignment="Center" Margin="14,0,0,0" FontSize="18" FontFamily="Microsoft YaHei"/>
        <Button Name="btnClose" Content="X" Width="44" Height="44" HorizontalAlignment="Right" Background="Transparent" Foreground="White" BorderThickness="0" FontSize="18" FontWeight="Bold"/>
      </Grid>
    </Border>
  </Grid>
</Window>
'@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$win = [Windows.Markup.XamlReader]::Load($reader)

$win.WindowStartupLocation = "Manual"
$win.Left = [System.Windows.SystemParameters]::PrimaryScreenWidth - 1100
$win.Top = 10

$wb = $win.FindName("wb")
$wb.Navigate($widgetPath)

$title = $win.FindName("titleBar")
$title.Add_MouseLeftButtonDown({ param($s,$e) $win.DragMove() })

$btn = $win.FindName("btnClose")
$btn.Add_Click({ $win.Close() })

$win.ShowDialog() | Out-Null

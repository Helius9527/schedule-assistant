Set oShell = CreateObject("WScript.Shell")
oShell.CurrentDirectory = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant"
oShell.Run "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe updater.py", 1, True
oShell.Run "powershell.exe -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\widget.ps1", 0, False

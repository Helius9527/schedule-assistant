Set oShell = CreateObject("WScript.Shell")
oShell.Run "powershell.exe -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\widget.ps1", 0, False

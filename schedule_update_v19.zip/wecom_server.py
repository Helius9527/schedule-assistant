#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
企业微信「日程助手」自建应用回调服务（明文模式，零第三方依赖）

能力：
  1) GET  -> 企微 URL 验证（SHA1 签名校验后回显 echostr）
  2) POST -> 接收消息，本地解析日程/冲突检测，被动回复

支持的对话：
  周二早上10点抽2个小时去A地考察   -> 解析+报冲突，等确认
  确认 / 是 / y                    -> 写入上一步待确认的条目
  取消 / 算了                      -> 丢弃
  今日 / 今天                      -> 查今日日程
  本周                             -> 查本周日程
  帮助                             -> 用法

启动： python wecom_server.py
"""
import os
import sys
import time
import hashlib
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import schedule_tool as st

# ==================== 配置区 ====================
# 必须与企微后台「接收消息-设置API接收」里填的 Token 完全一致
TOKEN = "JLCschedule2026"
PORT = 8000
# ================================================

PENDING = {}  # userid -> 待确认的条目

try:
    _log = os.path.join(BASE, "wecom_server.log")
    if sys.stdout is None:
        sys.stdout = open(_log, "a", encoding="utf-8")
    if sys.stderr is None:
        sys.stderr = open(_log, "a", encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def sha1_sig(token, timestamp, nonce, msg):
    arr = sorted([str(token), str(timestamp), str(nonce), str(msg)])
    return hashlib.sha1("".join(arr).encode("utf-8")).hexdigest()


def xml_to_dict(data):
    d = {}
    try:
        root = ET.fromstring(data)
        for c in root:
            d[c.tag] = c.text or ""
    except Exception:
        pass
    return d


def reply_xml(to_user, from_user, content):
    return ("<xml>"
            "<ToUserName><![CDATA[%s]]></ToUserName>"
            "<FromUserName><![CDATA[%s]]></FromUserName>"
            "<CreateTime>%d</CreateTime>"
            "<MsgType><![CDATA[text]]></MsgType>"
            "<Content><![CDATA[%s]]></Content>"
            "</xml>") % (to_user, from_user, int(time.time()), content)


def esc_cdata(s):
    return str(s).replace("]]>", "]]]]><![CDATA[>")


def fmt_list(rows):
    if not rows:
        return "（暂无安排）"
    return "\n".join("%s %s [%s] %s" % (r["day"], r["range"], r["type"], r["title"]) for r in rows)


def list_of(day=None):
    sch = st.load_schedule()
    rows = []
    for w in st.WD:
        if day and w != day:
            continue
        for it in sorted(sch.get(w, []), key=lambda x: (x.get("time") or "99")):
            rows.append({"day": w, "range": st.fmt_range(it.get("time"), st.dur_of(it)),
                         "title": it.get("title"), "type": it.get("type")})
    return rows


def handle_text(user, text):
    text = (text or "").strip()
    if not text:
        return "发一句人话就行，比如：\n周二早上10点抽2个小时去A地考察\n\n输入「帮助」看全部用法。"

    low = text.lower()

    if low in ("帮助", "help", "?"):
        return ("📋 用法\n"
                "• 直接说人话 → 解析并报冲突\n"
                "  例：周四下午3点评审会1小时\n"
                "• 确认 / 是 → 写入上一步\n"
                "• 取消 / 算了 → 丢弃\n"
                "• 今日 / 本周 → 查日程\n"
                "• 帮助 → 本说明")

    if low in ("确认", "是", "y", "yes", "ok", "写", "写入"):
        p = PENDING.get(user)
        if not p:
            return "没有待确认的条目。"
        sch = st.load_schedule()
        entry = {"time": p["time"], "duration": p["duration"], "title": p["title"],
                 "type": p["type"], "priority": p["priority"]}
        sch.setdefault(p["day"], []).append(entry)
        sch[p["day"]] = sorted(sch[p["day"]], key=lambda x: (x.get("time") or "99"))
        st.write_schedule(sch)
        del PENDING[user]
        return "✅ 已写入\n%s %s [%s] %s" % (p["day"], p["range"], p["type"], p["title"])

    if low in ("取消", "算了", "no", "n", "放弃"):
        if user in PENDING:
            del PENDING[user]
            return "已取消，未写入。"
        return "没有待确认的条目。"

    if low in ("今日", "今天", "今日日程"):
        return "📅 今日日程\n" + fmt_list(list_of(st.WD[__import__("datetime").datetime.now().weekday()]))

    if low in ("本周", "本周日程", "全览"):
        return "🗓 本周日程\n" + fmt_list(list_of())

    # 默认：当作新增日程解析
    p = st.parse_text(text)
    dur = p["duration"] if p["duration"] is not None else st.DEFAULT_DURATION
    sch = st.load_schedule()
    conflicts = st.find_conflicts(sch, p["day"], p["time"], dur)
    rng = st.fmt_range(p["time"], dur) if p["time"] else ("全天" if "全天" in text else "时间待定")

    PENDING[user] = {"day": p["day"], "time": p["time"], "duration": dur,
                     "title": p["title"], "type": p["type"], "priority": p["priority"],
                     "range": rng}

    msg = "📝 待添加\n%s %s  [%s/%s]\n%s" % (p["day"], rng, p["type"], p["priority"], p["title"])
    if conflicts:
        msg += "\n\n⚠ 检测到 %d 处冲突：" % len(conflicts)
        for c in conflicts:
            msg += "\n· 「%s」（%s-%s）" % (c["item"]["title"], c["start"], c["end"])
        msg += "\n\n仍要写入请回「确认」，放弃回「取消」。"
    else:
        msg += "\n\n✓ 无冲突，回「确认」写入。"
    return msg


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    def _send(self, body, ctype="text/xml; charset=utf-8"):
        b = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        """企微 URL 验证"""
        q = parse_qs(urlparse(self.path).query)
        g = lambda k: (q.get(k) or [""])[0]
        sig, ts, nonce, echostr = g("msg_signature"), g("timestamp"), g("nonce"), g("echostr")
        if sha1_sig(TOKEN, ts, nonce, echostr) == sig:
            sys.stderr.write("URL verified OK\n")
            self._send(echostr, "text/plain; charset=utf-8")
        else:
            sys.stderr.write("URL verify FAILED\n")
            self._send("fail", "text/plain; charset=utf-8")

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length)
        d = xml_to_dict(raw)
        user = d.get("FromUserName", "")
        content = d.get("Content", "")
        to = d.get("ToUserName", "")
        # 明文模式下无需解密；若收到 Encrypt 说明后台选了加密模式
        if "Encrypt" in d and not content:
            reply = "⚠ 当前是加密模式。请把企微后台「消息加解密方式」改成【明文模式】，本服务才能直接读取消息。"
        else:
            try:
                reply = handle_text(user, content)
            except Exception as e:
                reply = "处理出错：%s" % e
        self._send(reply_xml(user, to, esc_cdata(reply)))


if __name__ == "__main__":
    sys.stderr.write("WeCom schedule server on port %d, token=%s\n" % (PORT, TOKEN))
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()

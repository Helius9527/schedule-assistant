#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
日程推送脚本 —— 读取 data.js，生成当日/本周日程，推送到微信。
支持双通道（拿到哪个填哪个，都填就都推）：
  1) Server酱   -> 推到【个人微信】（服务号）
  2) 企业微信群机器人 -> 推到【企业微信群】
纯标准库，无需安装任何包。

用法：
  python push_schedule.py --today        # 推送今日日程
  python push_schedule.py --week         # 推送本周全览
  python push_schedule.py --upcoming     # 会前提醒（检查未来N分钟内的会议，自动去重）
  python push_schedule.py --today --dry  # 只打印不推送（调试用）
"""

import json
import os
import re
import sys
import argparse
import urllib.request
import urllib.parse
from datetime import datetime, timedelta

# Windows 控制台默认 GBK，强制 UTF-8；pythonw.exe 无控制台时改为追加写日志文件
try:
    import io
    _log = os.path.join(os.path.dirname(os.path.abspath(__file__)), "push.log")
    if sys.stdout is None:
        sys.stdout = open(_log, "a", encoding="utf-8")
    else:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    if sys.stderr is None:
        sys.stderr = open(_log, "a", encoding="utf-8")
    else:
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
except Exception:
    pass

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_JS = os.path.join(BASE, "data.js")
STATE_FILE = os.path.join(BASE, ".notify_state.json")

# ---- 密钥：优先从同目录 push_key.txt 读取（不写进代码，也不进更新包）----
# push_key.txt 每行一条：serverchan=xxx   或   wecom=xxx
SERVERCHAN_KEY = ""
WECOM_KEY = ""
_kf = os.path.join(BASE, "push_key.txt")
if os.path.exists(_kf):
    try:
        with open(_kf, "r", encoding="utf-8") as _fh:
            for _line in _fh:
                _line = _line.strip()
                if not _line or _line.startswith("#"):
                    continue
                if "=" not in _line:
                    continue
                _k, _v = _line.split("=", 1)
                _k, _v = _k.strip().lower(), _v.strip()
                if _k == "serverchan" and _v:
                    SERVERCHAN_KEY = _v
                elif _k == "wecom" and _v:
                    WECOM_KEY = _v
    except Exception:
        pass

# 会前提醒：提前多少分钟
LEAD_MINUTES = 10

PRI_ICON = {"高": "🔴", "中": "🟡", "低": "🟢"}
TYPE_TAG = {"会议": "会议", "事项": "事项"}
WD_CN = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def load_schedule():
    """从 data.js 中解析 window.WEEK_SCHEDULE"""
    with open(DATA_JS, "r", encoding="utf-8") as f:
        txt = f.read()
    m = re.search(r"window\.WEEK_SCHEDULE\s*=\s*(\{.*?\})\s*;\s*$", txt, re.S | re.M)
    if not m:
        m = re.search(r"window\.WEEK_SCHEDULE\s*=\s*(\{.*?\})\s*;", txt, re.S)
    if not m:
        raise RuntimeError("data.js 中未找到 WEEK_SCHEDULE，请检查文件格式")
    raw = m.group(1)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # 容错：允许 data.js 里写 JS 字面量（key 不带引号），自动补引号后再解析
        fixed = re.sub(r'([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)', r'\1"\2"\3', raw)
        return json.loads(fixed)


def weekday_cn(dt):
    return WD_CN[dt.weekday()]


def sort_items(items):
    return sorted(items, key=lambda x: (x.get("time") or "99"))


def fmt_line(it):
    icon = PRI_ICON.get(it.get("priority", "低"), "🟢")
    t = it.get("time") or "—"
    tag = it.get("type") or "事项"
    return "%s %s  [%s] %s" % (icon, t, tag, it.get("title", ""))


def build_today_msg(sch, now=None):
    now = now or datetime.now()
    wd = weekday_cn(now)
    items = sort_items(sch.get(wd, []))
    lines = ["📅 今日日程 | %d月%d日 %s" % (now.month, now.day, wd), "━━━━━━━━━━━━━━━━"]
    if items:
        for it in items:
            lines.append(fmt_line(it))
    else:
        lines.append("（今天暂无安排）")
    # 本周后续待办
    lines.append("━━━━━━━━━━━━━━━━")
    idx = now.weekday()
    pending = []
    for i in range(idx + 1, 7):
        w = WD_CN[i]
        for it in sort_items(sch.get(w, [])):
            pending.append("· %s %s %s" % (w, it.get("time") or "全天", it.get("title", "")))
    if pending:
        lines.append("本周还有：")
        lines.extend(pending)
    else:
        lines.append("本周后续暂无安排")
    return "\n".join(lines)


def build_week_msg(sch, now=None):
    now = now or datetime.now()
    lines = ["🗓 本周日程全览", "━━━━━━━━━━━━━━━━"]
    for w in WD_CN:
        items = sort_items(sch.get(w, []))
        if not items:
            continue
        lines.append("【%s】" % w)
        for it in items:
            lines.append("  " + fmt_line(it))
    return "\n".join(lines)


def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return set(json.load(f))
        except Exception:
            return set()
    return set()


def save_state(state):
    # 只保留最近 7 天，避免无限增长
    cutoff = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    kept = [k for k in state if k >= cutoff]
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(kept, f, ensure_ascii=False)


def build_upcoming(sch, now=None):
    """返回未来 LEAD_MINUTES 分钟内、尚未提醒过的会议/事项"""
    now = now or datetime.now()
    state = load_state()
    wd = weekday_cn(now)
    out = []
    for it in sort_items(sch.get(wd, [])):
        t = it.get("time") or ""
        m = re.match(r"^(\d{1,2}):(\d{2})", t)
        if not m:
            continue
        hh, mm = int(m.group(1)), int(m.group(2))
        start = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        delta = (start - now).total_seconds() / 60.0
        if 0 <= delta <= LEAD_MINUTES:
            key = "%s|%s|%s" % (now.strftime("%Y-%m-%d"), t, it.get("title", ""))
            if key not in state:
                out.append((key, int(round(delta)), it))
    return out


def send_serverchan(title, desp):
    if not SERVERCHAN_KEY:
        return False, "未配置 SERVERCHAN_KEY"
    url = "https://sctapi.ftqq.com/%s.send" % SERVERCHAN_KEY
    data = urllib.parse.urlencode({"title": title, "desp": desp}).encode("utf-8")
    req = urllib.request.Request(url, data=data)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return True, r.read().decode("utf-8", "ignore")
    except Exception as e:
        return False, str(e)


def send_wecom(content):
    if not WECOM_KEY:
        return False, "未配置 WECOM_KEY"
    url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=%s" % WECOM_KEY
    payload = json.dumps({"msgtype": "text", "text": {"content": content}}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return True, r.read().decode("utf-8", "ignore")
    except Exception as e:
        return False, str(e)


def push(title, content):
    """双通道推送，返回 [(通道名, 成功, 信息), ...]"""
    results = []
    ok1, msg1 = send_serverchan(title, content)
    results.append(("Server酱(个人微信)", ok1, msg1))
    ok2, msg2 = send_wecom(content)
    results.append(("企业微信机器人", ok2, msg2))
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--today", action="store_true", help="推送今日日程")
    ap.add_argument("--week", action="store_true", help="推送本周全览")
    ap.add_argument("--upcoming", action="store_true", help="会前提醒（自动去重）")
    ap.add_argument("--dry", action="store_true", help="只打印不推送")
    args = ap.parse_args()

    sch = load_schedule()

    if args.upcoming:
        ups = build_upcoming(sch)
        if not ups:
            print("[upcoming] 未来 %d 分钟内无待提醒事项" % LEAD_MINUTES)
            return
        state = load_state()
        for key, delta, it in ups:
            title = "⏰ %d分钟后有安排" % delta
            content = "%s\n%s" % (title, fmt_line(it))
            print("[upcoming] 提醒：%s" % content.replace("\n", " | "))
            if not args.dry:
                for ch, ok, msg in push(title, content):
                    print("  -> %s: %s %s" % (ch, "OK" if ok else "FAIL", "" if ok else msg))
                state.add(key)
        if not args.dry:
            save_state(state)
        return

    if args.week:
        title = "本周日程全览"
        content = build_week_msg(sch)
    else:
        title = "今日日程"
        content = build_today_msg(sch)

    print("=" * 46)
    print(content)
    print("=" * 46)

    if args.dry:
        print("[dry-run] 未实际推送")
        return

    for ch, ok, msg in push(title, content):
        print("-> %s: %s %s" % (ch, "OK" if ok else "FAIL", "" if ok else msg))


if __name__ == "__main__":
    main()

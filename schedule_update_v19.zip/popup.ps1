param([string]$t, [string]$m)
Add-Type -AssemblyName System.Windows.Forms
$null = [System.Windows.Forms.MessageBox]::Show(
  $m,
  $t,
  [System.Windows.Forms.MessageBoxButtons]::OK,
  [System.Windows.Forms.MessageBoxIcon]::Information,
  [System.Windows.Forms.MessageBoxDefaultButton]::Button1,
  [System.Windows.Forms.MessageBoxOptions]::DefaultDesktopOnly
)

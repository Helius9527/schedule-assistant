Set oShell = CreateObject("WScript.Shell")
oShell.CurrentDirectory = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant"
oShell.Run "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\reminder.py", 0, False

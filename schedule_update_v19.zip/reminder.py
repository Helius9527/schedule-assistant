#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
会前提醒守护进程 —— 不依赖微信，直接在桌面弹窗。

每 30 秒检查一次：若某条日程将在 LEAD_MINUTES 分钟内开始，且本次未提醒过，
则弹出 Windows 消息框（置顶）。

用法：
  python reminder.py          # 常驻后台（推荐加到开机启动）
  python reminder.py --once   # 只检查一次（调试用）
"""
import os
import sys
import json
import time
import subprocess
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import schedule_tool as st
import updater as up

STATE_FILE = os.path.join(BASE, ".notify_state.json")
POPUP_PS1 = os.path.join(BASE, "popup.ps1")
LEAD_MINUTES = 10
CHECK_INTERVAL = 30
# 每 60 个检查周期（约 30 分钟）顺带查一次新版本
UPDATE_CHECK_LOOPS = 60

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return set(json.load(f))
        except Exception:
            return set()
    return set()


def save_state(state):
    cutoff = (datetime.now() - __import__("datetime").timedelta(days=3)).strftime("%Y-%m-%d")
    kept = [k for k in state if k >= cutoff]
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(kept, f, ensure_ascii=False)
    except Exception:
        pass


def popup(title, msg):
    """调用 PowerShell 弹窗（置顶）"""
    try:
        subprocess.Popen(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-File", POPUP_PS1, "-t", title, "-m", msg],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        return True
    except Exception as e:
        print("弹窗失败：%s" % e)
        return False


def check_once():
    state = load_state()
    now = datetime.now()
    wd = st.WD[now.weekday()]
    now_min = now.hour * 60 + now.minute
    fired = []

    for it in st.load_schedule().get(wd, []):
        s = st.to_min(it.get("time", ""))
        if s is None:
            continue
        delta = s - now_min
        if 0 <= delta <= LEAD_MINUTES:
            key = "%s|%s|%s" % (now.strftime("%Y-%m-%d"), it.get("time"), it.get("title"))
            if key in state:
                continue
            msg = "还有 %d 分钟开始\n\n%s\n%s - %s（%d 分钟）" % (
                delta, it.get("title"),
                it.get("time"), st.to_hhmm(s + st.dur_of(it)), st.dur_of(it))
            if popup("日程提醒 · %s" % it.get("time"), msg):
                state.add(key)
                fired.append((it.get("time"), it.get("title"), delta))

    if fired:
        save_state(state)
    return fired


def check_update():
    """后台定期检查新版本，有则弹窗提示（复用 updater 的配置与版本读取）"""
    try:
        if not os.path.exists(up.CONFIG_FILE):
            return False
        with open(up.CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        vu = cfg.get("version_url", "").strip()
        if not vu or "http" not in vu:
            return False
        remote = up.fetch_json(vu, timeout=10)
        rver = int(remote.get("version", 0))
        lver = up.local_version()
        if rver > lver:
            popup("发现新版本 v%d" % rver,
                  "当前版本：v%d\n新版本：v%d\n\n更新内容：%s\n\n"
                  "请关闭悬浮窗，重新双击 启动.vbs 完成更新。"
                  % (lver, rver, remote.get("note", "（无说明）")))
            print("发现新版本 v%d（本地 v%d），已弹窗提示" % (rver, lver))
            return True
    except Exception as e:
        print("更新检查失败：%s" % e)
    return False


def main():
    once = "--once" in sys.argv
    print("会前提醒已启动（提前 %d 分钟，每 %d 秒检查；每约 %d 分钟查一次新版本）"
          % (LEAD_MINUTES, CHECK_INTERVAL, UPDATE_CHECK_LOOPS * CHECK_INTERVAL // 60))
    if once:
        fired = check_once()
        print("本次触发 %d 条" % len(fired))
        for t, ti, d in fired:
            print("  %s %s（%d 分钟后）" % (t, ti, d))
        return 0

    loop = 0
    while True:
        try:
            fired = check_once()
            for t, ti, d in fired:
                print("[%s] 已弹窗提醒：%s %s（%d 分钟后）"
                      % (datetime.now().strftime("%H:%M:%S"), t, ti, d))
        except Exception as e:
            print("检查出错：%s" % e)

        loop += 1
        if loop >= UPDATE_CHECK_LOOPS:
            loop = 0
            check_update()

        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    sys.exit(main())

@echo off
REM One-click install for JLC schedule push tasks (Windows Task Scheduler)
REM Creates 3 tasks that run silently in background, independent of WorkBuddy.
schtasks /create /tn "JLC_Schedule_Daily" /tr "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\push_schedule.py --today" /sc daily /st 09:00 /f
schtasks /create /tn "JLC_Schedule_Upcoming" /tr "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\push_schedule.py --upcoming" /sc minute /mo 5 /f
schtasks /create /tn "JLC_Schedule_Weekly" /tr "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\push_schedule.py --week" /sc weekly /d MON /st 09:00 /f
echo.
echo Installed 3 tasks:
echo   1. JLC_Schedule_Daily     - daily 09:00 today's schedule
echo   2. JLC_Schedule_Upcoming  - every 5 min, 10-min-before reminder
echo   3. JLC_Schedule_Weekly    - Monday 09:00 weekly overview
echo.
pause

---
name: schedule-assistant
description: 自然语言日程管理（云端版）。当用户提到时间与事项（如"周四下午3点评审会1小时""明天上午去现场"）、或说"安排/加个会/加日程/日程/今天有啥/冲突吗/提醒我"时使用。解析中文时间、查云端表做冲突检测、确认后写入 WorkBuddy 资料库在线表。
agent_created: true
---

# 日程助手（云端版）

日程数据存在 **WorkBuddy 资料库在线表**，不存本地文件。好处：多人共享同一份数据、改规则即时生效、不需要分发任何文件。

## 数据表

- 名称：**日程表**
- `database_id`：`FSZ9syszFAdRrGcwEATNwe`

| 字段 | 类型 | 说明 |
|---|---|---|
| 标题 | text | 事项名称 |
| 日期 | text | `YYYY-MM-DD`（**必须换算成具体日期**，不能存"周四"） |
| 开始时间 | text | `HH:MM`；全天留空 |
| 时长 | number | 分钟；0 或缺失按 60 算 |
| 类型 | select | `会议` / `事项` |
| 优先级 | select | `高` / `中` / `低` |
| 地点 | text | 可选 |

## 调用前置（每次操作云端表都要做）

1. 先跑一次判断运行模式：
```
python3 "<skill_dir>/runtime_context.py"
```
2. 若输出 `mode=client`：用 `ToolSearch` 查 `connect_open_platform`，再用 `DeferExecuteTool` 调用 `{"toolName":"connect_open_platform","params":{"skill_id":"library"}}` 拿到 token。
3. 调脚本时把 token 从 stdin 首行传入，并带 `--token-stdin`：
```
printf '%s' "<token>" | python3 "<skill_dir>/database/<script>.py" --token-stdin <其它参数>
```
脚本目录：`C:/Users/JLC/.workbuddy/plugins/cache/workbuddy-builtin/skill-library/0.5.9/database/`

## 工作流（严格遵守：先查后报，确认再写）

**第 1 步 · 解析**。从用户原话里提取：日期、开始时间、时长、类型、优先级、标题。

- 日期：`今天` `明天` `后天` `周一`…`周日` → 一律换算成**具体日期**（用今天的真实日期推算）
- 时间：`下午3点`→15:00、`4点半`→16:30、`14:30` 直接用；`上午`默认09:00、`下午`默认14:00；`全天`则开始时间留空
- 时长：`2个小时`→120、`半小时`→30、`一个半小时`→90、`10点到12点`→120；没提按 **60**
- 类型：含「会议/开会/评审/论证/议价/汇报/沟通/对接/例会/讨论/面谈/面试/碰头」或形如 `XX会`（如协调会、周会、启动会）→ `会议`；否则 `事项`
- 优先级：含「重要/紧急/务必/必须/关键」→ `高`；否则 `中`

**第 2 步 · 查冲突**。查该日期已有记录：
```
printf '%s' "<token>" | python3 ".../query_database_record.py" --token-stdin --database-id "FSZ9syszFAdRrGcwEATNwe" --filter '{"property":"日期","text":{"equals":"YYYY-MM-DD"}}'
```
区间重叠判定（时长缺失按 60）：`新start < 已有s+已有d` 且 `已有s < 新start+新d` → 冲突。

**第 3 步 · 先报后写**。把「日期 时间区间 标题 类型」和冲突清单（撞了哪几条、各自几点到几点）**告诉用户，等确认**。

> 即使用户说过"无论冲不冲突都写"，也**必须先把冲突列给他看**，得到明确确认后才写入。绝不静默写入。

**第 4 步 · 确认后写入**：
```
printf '%s' "<token>" | python3 ".../batch_add_database_records.py" --token-stdin --database-id "FSZ9syszFAdRrGcwEATNwe" --records '[{"标题":{"text":"..."},"日期":{"text":"2026-09-10"},"开始时间":{"text":"14:00"},"时长":{"number":120},"类型":{"select":"会议"},"优先级":{"select":"高"},"地点":{"text":""}}]'
```

## 常用命令

```
# 查某天 / 某段
.../query_database_record.py --token-stdin --database-id "<db>" --filter '{"property":"日期","text":{"equals":"2026-09-10"}}'
# 导出全部（CSV）
.../get_database_content.py --token-stdin --database-id "<db>"
# 修改（需 record_id）
.../batch_update_database_records.py --token-stdin --database-id "<db>" --records '[{"record_id":"...","properties":{"开始时间":{"text":"15:00"}}}]'
# 删除（需用户明确要求且已确定目标）
.../batch_delete_database_records.py --token-stdin --database-id "<db>" --record-ids '["..."]'
```

## 注意

- 数据只存 WorkBuddy 资料库，**不读、不存、不传输任何聊天内容**；用户没说的机密（报价、人事、合同条款）一律不碰。
- 删除记录属不可逆操作，必须用户明确点名要删哪几条。
- 若用户提到"今天的日程""本周安排"，直接查表汇总给他，无需确认。

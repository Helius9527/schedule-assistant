// 日程数据模板（初始为空）
// 字段：time 开始时间(空串=全天) / duration 时长(分钟,缺省60) / title 事项 / type 会议|事项 / priority 高|中|低
// 直接说人话让 AI 帮你加即可，不用手改这个文件。
window.WEEK_SCHEDULE = {};

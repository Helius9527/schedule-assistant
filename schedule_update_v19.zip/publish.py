#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
一键发布：把最新更新包 + version.json 自动推到 GitHub 仓库。
对方（领导）启动悬浮窗时会自动发现新版本，点确认即升级。

用法：
  python publish.py                 # 发布当前版本
  python publish.py --note "修了XX"  # 附带更新说明
"""
import os
import re
import sys
import json
import glob
import base64
import urllib.request
import urllib.error

BASE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(BASE, "dist")
KEY_FILE = os.path.join(BASE, "push_key.txt")
REPO = "Helius9527/schedule-assistant"
BRANCH = "main"

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def read_github_token():
    if not os.path.exists(KEY_FILE):
        return ""
    try:
        with open(KEY_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k.strip().lower() == "github" and v.strip():
                    return v.strip()
    except Exception:
        pass
    return ""


def api(method, path, token, payload=None):
    url = "https://api.github.com/repos/%s/contents/%s" % (REPO, path)
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": "Bearer " + token,
        "Accept": "application/vnd.github+json",
        "User-Agent": "schedule-publisher",
        "Content-Type": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8", "ignore"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")
        return {"error": "HTTP %s: %s" % (e.code, body[:200])}


def get_sha(path, token):
    res = api("GET", path + "?ref=" + BRANCH, token)
    return res.get("sha")


def put_file(local_path, remote_path, message, token):
    with open(local_path, "rb") as f:
        content = base64.b64encode(f.read()).decode("ascii")
    sha = get_sha(remote_path, token)
    payload = {"message": message, "content": content, "branch": BRANCH}
    if sha:
        payload["sha"] = sha  # 已存在则更新
    res = api("PUT", remote_path, token, payload)
    if "error" in res:
        return False, res["error"]
    return True, res.get("content", {}).get("name", remote_path)


def main():
    note = ""
    if "--note" in sys.argv:
        i = sys.argv.index("--note")
        if i + 1 < len(sys.argv):
            note = sys.argv[i + 1]

    token = read_github_token()
    if not token:
        print("未找到 GitHub Token。请在 push_key.txt 里加一行：github=你的token")
        return 1

    def _vnum(p):
        m = re.search(r"_v(\d+)\.zip$", os.path.basename(p))
        return int(m.group(1)) if m else 0
    zips = sorted(glob.glob(os.path.join(DIST, "*.zip")), key=_vnum)
    if not zips:
        print("dist 里没有更新包，先运行 build_update.py")
        return 1
    zip_path = zips[-1]
    zip_name = os.path.basename(zip_path)

    ver_file = os.path.join(DIST, "version.json")
    if not os.path.exists(ver_file):
        print("dist/version.json 不存在")
        return 1

    # 用命令行 --note 覆盖 version.json 里的说明
    if note:
        vj = json.load(open(ver_file, encoding="utf-8"))
        vj["note"] = note
        json.dump(vj, open(ver_file, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    ver = json.load(open(ver_file, encoding="utf-8")).get("version", "?")
    print("准备发布 v%s" % ver)
    print("  仓库：%s (分支 %s)" % (REPO, BRANCH))

    ok1, msg1 = put_file(zip_path, zip_name, "release v%s" % ver, token)
    print("  上传 %-28s %s" % (zip_name, "OK" if ok1 else "FAIL " + str(msg1)))

    ok2, msg2 = put_file(ver_file, "version.json", "version v%s" % ver, token)
    print("  上传 %-28s %s" % ("version.json", "OK" if ok2 else "FAIL " + str(msg2)))

    if ok1 and ok2:
        print("\n发布完成。对方的悬浮窗下次启动时会看到 v%s 更新提示。" % ver)
        print("下载地址：https://raw.githubusercontent.com/%s/%s/%s" % (REPO, BRANCH, zip_name))
        return 0
    print("\n发布未完全成功，请检查上面的错误信息。")
    return 1


if __name__ == "__main__":
    sys.exit(main())

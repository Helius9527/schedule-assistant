#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
自动更新器 —— 启动时检查新版本，弹窗让你点确认，然后自动下载覆盖。

保护规则：永远不覆盖 data.js（你的日程）、push_key.txt（密钥）、update_config.json。

用法：
  python updater.py            # 检查并询问
  python updater.py --silent   # 只检查不弹窗（用于后台）

更新源配置见同目录 update_config.json：
  {"version_url": "https://.../version.json"}
远程 version.json 格式：
  {"version": 2, "note": "修复了XX", "url": "https://.../schedule_update_v2.zip"}
"""
import os
import sys
import json
import zipfile
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE, "update_config.json")
VERSION_FILE = os.path.join(BASE, "VERSION")

# 这些文件更新时绝不动：对方的日程数据、密钥、更新源配置
# 注：updater.py 不在此列——Python 已把自身载入内存，覆盖文件不影响当前进程，下次启动即新版
PROTECTED = {"data.js", "push_key.txt", "update_config.json",
             ".notify_state.json", "VERSION"}

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def log(msg):
    try:
        with open(os.path.join(BASE, "updater.log"), "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass
    print(msg)


def local_version():
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                return int(f.read().strip() or 0)
        except Exception:
            return 0
    return 0


def write_version(v):
    try:
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            f.write(str(v))
    except Exception:
        pass


def ask(title, msg):
    """弹窗确认；无图形环境时回退到命令行"""
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        res = messagebox.askyesno(title, msg)
        root.destroy()
        return res
    except Exception:
        try:
            ans = input(msg + " (y/n): ").strip().lower()
            return ans in ("y", "yes", "是")
        except Exception:
            return False


def show_info(title, msg):
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showinfo(title, msg)
        root.destroy()
    except Exception:
        print(msg)


def fetch_json(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": "schedule-updater"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))


def download(url, dest, timeout=90):
    req = urllib.request.Request(url, headers={"User-Agent": "schedule-updater"})
    with urllib.request.urlopen(req, timeout=timeout) as r, open(dest, "wb") as f:
        f.write(r.read())


def apply_zip(zip_path, remote_ver):
    """解压覆盖，跳过受保护文件"""
    applied = []
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            base = os.path.basename(name)
            if not base or base in PROTECTED:
                continue
            # 只处理根目录文件（不解压子目录，避免污染）
            if "/" in name or "\\" in name:
                continue
            target = os.path.join(BASE, base)
            try:
                with z.open(name) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                applied.append(base)
            except Exception as e:
                log("  跳过 %s：%s" % (base, e))
    write_version(remote_ver)
    return applied


def main():
    silent = "--silent" in sys.argv

    if not os.path.exists(CONFIG_FILE):
        log("未找到 update_config.json，跳过更新检查。")
        return 0

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        log("配置文件读取失败：%s" % e)
        return 0

    version_url = cfg.get("version_url", "").strip()
    if not version_url or "http" not in version_url:
        log("未配置 version_url，跳过更新检查。")
        return 0

    try:
        remote = fetch_json(version_url)
    except Exception as e:
        log("检查更新失败（网络不通或地址有误）：%s" % e)
        if not silent:
            show_info("检查更新", "没能连上更新服务器，继续使用当前版本。\n\n(%s)" % e)
        return 0

    rver = int(remote.get("version", 0))
    lver = local_version()
    log("本地 v%d，远程 v%d" % (lver, rver))

    if rver <= lver:
        log("已是最新，无需更新。")
        if not silent:
            show_info("检查更新", "当前已是最新版本（v%d）。" % lver)
        return 0

    note = remote.get("note", "（无说明）")
    pkg_url = remote.get("url", "")
    if not pkg_url:
        log("远程未提供下载地址，跳过。")
        return 0

    if silent:
        return 1  # 有新版本，交给调用方处理

    ok = ask("发现新版本",
             "当前版本：v%d\n新版本：v%d\n\n更新内容：\n%s\n\n是否现在更新？\n"
             "（你的日程数据不会被覆盖）" % (lver, rver, note))
    if not ok:
        log("用户取消更新。")
        return 0

    tmp = os.path.join(BASE, "_update_tmp.zip")
    try:
        log("开始下载：%s" % pkg_url)
        download(pkg_url, tmp)
        applied = apply_zip(tmp, rver)
        log("更新完成，覆盖文件：%s" % ", ".join(applied))
        show_info("更新完成",
                  "已更新到 v%d。\n\n更新了 %d 个文件，你的日程数据保持不变。\n"
                  "请关闭并重新打开悬浮窗以生效。" % (rver, len(applied)))
    except Exception as e:
        log("更新失败：%s" % e)
        show_info("更新失败", "更新过程中出错，当前版本未改动。\n\n%s" % e)
        return 1
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

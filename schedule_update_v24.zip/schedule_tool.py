#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
日程工具：自然语言添加 + 冲突检测
用法：
  python schedule_tool.py list [--json]
  python schedule_tool.py check --day 周二 --time 10:00 --duration 120
  python schedule_tool.py add --text "周二早上10点抽2个小时去A地考察"        # 只预览，不写入
  python schedule_tool.py add --text "周二早上10点抽2个小时去A地考察" --force # 确认写入
  python schedule_tool.py add --day 周二 --time 10:00 --duration 120 --title "A地考察" --force
"""
import json, os, re, sys, argparse
from datetime import datetime, timedelta

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_JS = os.path.join(BASE, "data.js")

try:
    import io
    if sys.stdout is None:
        sys.stdout = open(os.path.join(BASE, "tool.log"), "a", encoding="utf-8")
    else:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
except Exception:
    pass

WD = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
CN_NUM = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
          "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
DEFAULT_DURATION = 60


def load_schedule():
    with open(DATA_JS, "r", encoding="utf-8") as f:
        txt = f.read()
    m = re.search(r"window\.WEEK_SCHEDULE\s*=\s*(\{.*?\})\s*;", txt, re.S)
    if not m:
        raise RuntimeError("data.js 未找到 WEEK_SCHEDULE")
    raw = m.group(1)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        fixed = re.sub(r'([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)', r'\1"\2"\3', raw)
        return json.loads(fixed)


def write_schedule(sch):
    with open(DATA_JS, "r", encoding="utf-8") as f:
        txt = f.read()
    new_block = "window.WEEK_SCHEDULE = " + json.dumps(sch, ensure_ascii=False, indent=2) + ";"
    txt = re.sub(r"window\.WEEK_SCHEDULE\s*=\s*\{.*?\}\s*;", new_block, txt, flags=re.S)
    with open(DATA_JS, "w", encoding="utf-8") as f:
        f.write(txt)


def to_min(t):
    if not t:
        return None
    m = re.match(r"^\s*(\d{1,2})\s*[:：]\s*(\d{2})\s*$", str(t))
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))
    m = re.match(r"^\s*(\d{1,2})\s*$", str(t))
    if m:
        return int(m.group(1)) * 60
    return None


def to_hhmm(mins):
    return "%02d:%02d" % (mins // 60, mins % 60)


def dur_of(it):
    d = it.get("duration", None)
    if d is None:
        return DEFAULT_DURATION
    try:
        d = int(d)
    except Exception:
        return DEFAULT_DURATION
    return d if d > 0 else DEFAULT_DURATION


def find_conflicts(sch, day, time_str, duration):
    """返回与该时段重叠的已有条目列表"""
    start = to_min(time_str)
    if start is None:
        return []
    end = start + (duration or DEFAULT_DURATION)
    out = []
    for it in sch.get(day, []):
        s = to_min(it.get("time", ""))
        if s is None:
            continue
        e = s + dur_of(it)
        if start < e and s < end:
            out.append({"item": it, "start": to_hhmm(s), "end": to_hhmm(e)})
    return out


# ---------- 自然语言解析 ----------
def cn_num(s):
    if not s:
        return None
    if s in CN_NUM:
        return CN_NUM[s]
    if "十" in s:
        p = s.split("十")
        if p[0] == "":
            return 10 + (CN_NUM.get(p[1], 0) if len(p) > 1 and p[1] else 0)
        return CN_NUM.get(p[0], 0) * 10 + (CN_NUM.get(p[1], 0) if len(p) > 1 and p[1] else 0)
    return None


def parse_duration(text):
    """从中文里提取时长(分钟)"""
    # 起止时间：10点到12点 / 10:00-12:00
    m = re.search(r"(\d{1,2})\s*(?:[:：点])?\s*(\d{2})?\s*(?:到|-|~|至|—)\s*(\d{1,2})\s*(?:[:：点])\s*(\d{2})?", text)
    if m:
        a = int(m.group(1)) * 60 + (int(m.group(2)) if m.group(2) else 0)
        b = int(m.group(3)) * 60 + (int(m.group(4)) if m.group(4) else 0)
        if b > a:
            return b - a, (m.group(0), None, None)
    # N个小时 / N小时
    m = re.search(r"([\d零一二三四五六七八九十两]+)\s*个?\s*小时(半)?", text)
    if m:
        n = cn_num(m.group(1)) if not m.group(1).isdigit() else int(m.group(1))
        if n is not None:
            return n * 60 + (30 if m.group(2) else 0), (m.group(0), None, None)
    # N个小时半 / N小时半
    m = re.search(r"([\d零一二三四五六七八九十两]+)\s*个?\s*(?:小时|钟头)\s*半", text)
    if m:
        n = cn_num(m.group(1)) if not m.group(1).isdigit() else int(m.group(1))
        if n is not None:
            return n * 60 + 30, (m.group(0), None, None)
    # 半小时
    if re.search(r"半个?(小时|钟头)", text):
        return 30, ("半小时", None, None)
    # N分钟
    m = re.search(r"([\d零一二三四五六七八九十两]+)\s*分钟", text)
    if m:
        n = cn_num(m.group(1)) if not m.group(1).isdigit() else int(m.group(1))
        if n is not None:
            return n, (m.group(0), None, None)
    return None, (None, None, None)


def parse_text(text):
    now = datetime.now()
    # 星期
    day = None
    wd_map = {"周一": 0, "周二": 1, "周三": 2, "周四": 3, "周五": 4, "周六": 5, "周日": 6,
              "星期一": 0, "星期二": 1, "星期三": 2, "星期四": 3, "星期五": 4, "星期六": 5, "星期日": 6, "星期天": 6}
    if "今天" in text:
        day = WD[now.weekday()]
    elif "明天" in text:
        day = WD[(now.weekday() + 1) % 7]
    elif "后天" in text:
        day = WD[(now.weekday() + 2) % 7]
    else:
        for k, v in wd_map.items():
            if k in text:
                day = WD[v]
                break
    if day is None:
        day = WD[now.weekday()]

    # 开始时间
    time_str = ""
    m = re.search(r"(\d{1,2})\s*[:：]\s*(\d{2})", text)
    if m:
        time_str = "%02d:%02d" % (int(m.group(1)), int(m.group(2)))
    else:
        m = re.search(r"(上午|中午|下午|晚上|早上|傍晚)?\s*([\d零一二三四五六七八九十两]+)\s*点\s*(半|一刻)?", text)
        if m:
            raw = m.group(2)
            h = cn_num(raw) if not raw.isdigit() else int(raw)
            mi = 30 if m.group(3) == "半" else (15 if m.group(3) == "一刻" else 0)
            per = m.group(1) or ""
            if per in ("下午", "晚上", "傍晚") and h < 12:
                h += 12
            if per == "中午" and h < 12:
                h = 12
            time_str = "%02d:%02d" % (h, mi)
        elif "上午" in text:
            time_str = "09:00"
        elif "下午" in text:
            time_str = "14:00"
        elif "晚上" in text:
            time_str = "19:00"

    duration, (dseg, _, _) = parse_duration(text)

    if "全天" in text:
        time_str = ""

    # 类型 / 优先级
    itype = "会议" if re.search(r"会议|开会|评审|论证|议价|汇报|沟通|对接|例会|讨论|面谈|面试|碰头|[一-龥]{1,4}会(?!议)", text) else "事项"
    prio = "高" if re.search(r"重要|紧急|务必|必须|关键", text) else "中"

    # 标题：剥掉时间/时长/日期词
    title = text
    if dseg:
        title = title.replace(dseg, "")
    title = re.sub(r"(今天|明天|后天)", "", title)
    title = re.sub(r"(上午|中午|下午|晚上|早上|傍晚)?\s*\d{1,2}\s*[:：]\s*\d{2}", "", title)
    title = re.sub(r"(上午|中午|下午|晚上|早上|傍晚)?\s*[\d零一二三四五六七八九十两]+\s*点\s*(半|一刻)?", "", title)
    title = re.sub(r"星期[一二三四五六日天]", "", title)
    title = re.sub(r"周[一二三四五六日天]", "", title)
    title = re.sub(r"[\d零一二三四五六七八九十两]+\s*个?\s*小时(半)?", "", title)
    title = re.sub(r"(半个?(小时|钟头)|半小时)", "", title)
    title = re.sub(r"[\d零一二三四五六七八九十两]+\s*分钟", "", title)
    title = re.sub(r"全天", "", title)
    title = re.sub(r"(上午|中午|下午|晚上|早上|傍晚)", "", title)
    title = re.sub(r"^[的\s,，、。抽留出安排去]+", "", title)
    title = re.sub(r"[\s,，、。]+$", "", title)
    if not title:
        title = text

    return {"day": day, "time": time_str, "duration": duration, "title": title,
            "type": itype, "priority": prio}


def fmt_range(time_str, duration):
    s = to_min(time_str)
    if s is None:
        return "全天"
    return "%s-%s" % (time_str, to_hhmm(s + (duration or DEFAULT_DURATION)))


def main():
    # --from-file <path>: 从文件读 text（避免命令行 quoting / 跨进程 marshaling 问题）
    if "--from-file" in sys.argv:
        i = sys.argv.index("--from-file")
        fp = sys.argv[i + 1]
        try:
            with open(fp, encoding="utf-8") as fh:
                text = fh.read().strip()
        except Exception as e:
            print("读文件失败：" + str(e))
            return 1
        sys.argv = sys.argv[:i] + ["--text", text] + sys.argv[i + 2:]

    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["list", "check", "add"])
    ap.add_argument("--text", help="自然语言，如：周二早上10点抽2个小时去A地考察")
    ap.add_argument("--day", help="周一~周日")
    ap.add_argument("--time", help="开始时间 HH:MM")
    ap.add_argument("--duration", type=int, help="时长(分钟)")
    ap.add_argument("--title")
    ap.add_argument("--type", default=None)
    ap.add_argument("--priority", default=None)
    ap.add_argument("--force", action="store_true", help="确认写入（否则只预览）")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    sch = load_schedule()

    if args.cmd == "list":
        rows = []
        for w in WD:
            for it in sorted(sch.get(w, []), key=lambda x: (x.get("time") or "99")):
                rows.append({"day": w, "time": it.get("time") or "",
                             "range": fmt_range(it.get("time"), dur_of(it)),
                             "title": it.get("title"), "type": it.get("type"),
                             "priority": it.get("priority")})
        if args.json:
            print(json.dumps(rows, ensure_ascii=False))
        else:
            if not rows:
                print("本周暂无安排")
            for r in rows:
                print("%s %s  [%s/%s] %s" % (r["day"], r["range"], r["type"], r["priority"], r["title"]))
        return

    # 解析参数
    if args.text:
        p = parse_text(args.text)
        day = p["day"]; time_str = p["time"]; duration = p["duration"]
        title = args.title or p["title"]
        itype = args.type or p["type"]
        prio = args.priority or p["priority"]
    else:
        day = args.day or WD[datetime.now().weekday()]
        time_str = args.time or ""
        duration = args.duration
        title = args.title or ""
        itype = args.type or "事项"
        prio = args.priority or "中"

    if duration is None:
        duration = DEFAULT_DURATION

    conflicts = find_conflicts(sch, day, time_str, duration)
    if time_str:
        rng = fmt_range(time_str, duration)
    else:
        rng = "全天" if "全天" in (args.text or "") else "时间待定"

    if args.cmd == "check" or not args.force:
        res = {"action": "preview", "day": day, "time": time_str, "duration": duration,
               "range": rng, "title": title, "type": itype,
               "priority": prio, "conflicts": conflicts}
        if args.json:
            print(json.dumps(res, ensure_ascii=False))
            return
        print("待添加：%s %s  [%s/%s] %s" % (day, res["range"], itype, prio, title))
        if conflicts:
            print("⚠ 检测到 %d 处时间冲突：" % len(conflicts))
            for c in conflicts:
                print("   · 与「%s」冲突（已有 %s-%s）" % (c["item"]["title"], c["start"], c["end"]))
        else:
            print("✓ 无冲突")
        if not args.force:
            print("\n（预览模式，未写入。确认后加 --force 写入）")
        return

    # 写入
    entry = {"time": time_str, "duration": duration, "title": title, "type": itype, "priority": prio}
    sch.setdefault(day, []).append(entry)
    sch[day] = sorted(sch[day], key=lambda x: (x.get("time") or "99"))
    write_schedule(sch)
    res = {"action": "added", "day": day, "range": fmt_range(time_str, duration),
           "title": title, "conflict_count": len(conflicts)}
    if args.json:
        print(json.dumps(res, ensure_ascii=False))
    else:
        print("✓ 已写入：%s %s [%s/%s] %s" % (day, res["range"], itype, prio, title))
        if conflicts:
            print("  注意：存在 %d 处冲突（按你的要求仍然写入）" % len(conflicts))


if __name__ == "__main__":
    main()

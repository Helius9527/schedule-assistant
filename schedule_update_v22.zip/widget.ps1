# JLC schedule desktop gadget (WinForms + system tray)
# Pure ASCII content; all Chinese text lives in schedule-widget.html (UTF-8).
#
# Behaviour:
#   - NOT always-on-top by default (toggle: P button or tray menu)
#   - X / _ hides to tray (process keeps running); click tray icon to restore
#   - The HTML page owns the input box; JS calls window.external.AddEvent(text)
#     and this host writes data.js via schedule_tool.py
#   - FileSystemWatcher on data.js -> auto refresh the page
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "SilentlyContinue"
$workDir = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant"
$widgetUrl = "file:///" + ($workDir -replace '\\', '/') + "/schedule-widget.html"
$scheduleTool = Join-Path $workDir "schedule_tool.py"
$updaterPy = Join-Path $workDir "updater.py"
$pyExe = "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\python.exe"
$W = 640
$H = 820

Add-Type -Namespace Win32Native -Name Api -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern int SendMessage(System.IntPtr hWnd, int Msg, int wParam, int lParam);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool ReleaseCapture();
'@

# COM-visible bridge: lets the page call into this host (window.external)
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Diagnostics;

[ComVisible(true)]
public class ScheduleBridge
{
    public string ToolPath = "";
    public string WorkDir = "";
    public string PyExe = "";

    [ComVisible(true)]
    public int AddEvent(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return -1;
        try
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = PyExe;
            psi.Arguments = "\"" + ToolPath + "\" add --text \"" + text.Replace("\"", "'") + "\" --force";
            psi.WorkingDirectory = WorkDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            Process p = Process.Start(psi);
            p.WaitForExit(15000);
            return p.ExitCode;
        }
        catch { return -2; }
    }
}
'@ -ReferencedAssemblies System.Windows.Forms, System.Drawing

$script:reallyExit = $false

$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$form.Text = "Schedule"
$form.Size = New-Object System.Drawing.Size($W, $H)
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$form.Location = New-Object System.Drawing.Point(
    ([System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width - $W - 20), 20)
$form.TopMost = $false
$form.ShowInTaskbar = $true
$form.BackColor = [System.Drawing.Color]::White

$wb = New-Object System.Windows.Forms.WebBrowser
$wb.Dock = [System.Windows.Forms.DockStyle]::Fill
$wb.ScriptErrorsSuppressed = $true
$wb.IsWebBrowserContextMenuEnabled = $false

$bridge = New-Object ScheduleBridge
$bridge.ToolPath = $scheduleTool
$bridge.WorkDir = $workDir
$bridge.PyExe = $pyExe
$wb.ObjectForScripting = $bridge
$wb.Url = New-Object System.Uri($widgetUrl)
$form.Controls.Add($wb)

$head = New-Object System.Windows.Forms.Panel
$head.Dock = [System.Windows.Forms.DockStyle]::Top
$head.Height = 28
$head.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
$head.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
        [Win32Native.Api]::ReleaseCapture() | Out-Null
        [Win32Native.Api]::SendMessage($form.Handle, 0xA1, 0x2, 0) | Out-Null
    }
})
$form.Controls.Add($head)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "Schedule"
$titleLabel.ForeColor = [System.Drawing.Color]::White
$titleLabel.Dock = [System.Windows.Forms.DockStyle]::Left
$titleLabel.Width = 420
$titleLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$titleLabel.Font = New-Object System.Drawing.Font("Microsoft YaHei", 10, [System.Drawing.FontStyle]::Bold)
$head.Controls.Add($titleLabel)

function New-HeadButton {
    param([string]$t)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $t
    $b.Width = 34
    $b.Height = 28
    $b.Dock = [System.Windows.Forms.DockStyle]::Right
    $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $b.FlatAppearance.BorderSize = 0
    $b.ForeColor = [System.Drawing.Color]::White
    $b.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
    $b.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    return $b
}

$btnClose = New-HeadButton "X"
$btnMin = New-HeadButton "_"
$btnPin = New-HeadButton "P"
$head.Controls.Add($btnClose)
$head.Controls.Add($btnMin)
$head.Controls.Add($btnPin)

# auto refresh whenever data.js is written (host, or edited elsewhere)
$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = $workDir
$watcher.Filter = "data.js"
$watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite
$watcher.EnableRaisingEvents = $true
$watcher.Add_Changed({
    try { $form.BeginInvoke([System.Action]{ $wb.Refresh() }) } catch {}
})

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon((Get-Process -Id $PID).Path)
$notify.Text = "Schedule Assistant - click to show / hide"
$notify.Visible = $true

$toggle = {
    if ($form.Visible) { $form.Hide() }
    else { $form.Show(); $form.Activate() }
}
$notify.Add_Click($toggle)

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miShow = $menu.Items.Add("Show / Hide")
$miShow.Add_Click($toggle)
$miPin = $menu.Items.Add("Always on top")
$miPin.Add_Click({ $form.TopMost = -not $form.TopMost })
$miReload = $menu.Items.Add("Reload")
$miReload.Add_Click({ $wb.Refresh() })
$miUpdate = $menu.Items.Add("Check for updates")
$miUpdate.Add_Click({
    Start-Process -FilePath $pyExe -ArgumentList "`"$updaterPy`"" -WorkingDirectory $workDir
})
$miExit = $menu.Items.Add("Exit")
$miExit.Add_Click({
    $script:reallyExit = $true
    $notify.Visible = $false
    $notify.Dispose()
    $form.Close()
})
$notify.ContextMenuStrip = $menu

$btnPin.Add_Click({ $form.TopMost = -not $form.TopMost })
$btnMin.Add_Click({ $form.Hide() })
$btnClose.Add_Click({ $form.Hide() })

$form.Add_FormClosing({
    param($s, $e)
    if ($script:reallyExit) { return }
    $e.Cancel = $true
    $form.Hide()
})

[System.Windows.Forms.Application]::Run($form) | Out-Null
try { $watcher.Dispose() } catch {}
try { $notify.Dispose() } catch {}

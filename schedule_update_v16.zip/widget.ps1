# JLC schedule desktop gadget (WinForms + system tray)
# Pure ASCII content; all Chinese text lives in schedule-widget.html (UTF-8).
# Behaviour:
#   - NOT always-on-top by default (toggle with the P button or tray menu)
#   - X / _ hides the window to the system tray (process keeps running)
#   - Click the tray icon to show/hide; right-click for menu (topmost/reload/exit)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic

$ErrorActionPreference = "SilentlyContinue"
$widgetUrl = "file:///C:/Users/JLC/WorkBuddy/2026-09-05-17-00-34/schedule-assistant/schedule-widget.html"
$scheduleTool = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\schedule_tool.py"
$W = 640
$H = 820

Add-Type -Namespace Win32Native -Name Api -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern int SendMessage(System.IntPtr hWnd, int Msg, int wParam, int lParam);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool ReleaseCapture();
'@

$script:reallyExit = $false

$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$form.Text = "Schedule"
$form.Size = New-Object System.Drawing.Size($W, $H)
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$form.Location = New-Object System.Drawing.Point(
    ([System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width - $W - 20), 20)
$form.TopMost = $false
$form.ShowInTaskbar = $true
$form.BackColor = [System.Drawing.Color]::White

# ---- web browser (fill) ----
$wb = New-Object System.Windows.Forms.WebBrowser
$wb.Dock = [System.Windows.Forms.DockStyle]::Fill
$wb.ScriptErrorsSuppressed = $true
$wb.IsWebBrowserContextMenuEnabled = $false
$wb.Url = New-Object System.Uri($widgetUrl)
$form.Controls.Add($wb)

# ---- header bar (top) ----
$head = New-Object System.Windows.Forms.Panel
$head.Dock = [System.Windows.Forms.DockStyle]::Top
$head.Height = 28
$head.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
$head.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
        [Win32Native.Api]::ReleaseCapture() | Out-Null
        [Win32Native.Api]::SendMessage($form.Handle, 0xA1, 0x2, 0) | Out-Null
    }
})
$form.Controls.Add($head)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "Schedule"
$titleLabel.ForeColor = [System.Drawing.Color]::White
$titleLabel.Dock = [System.Windows.Forms.DockStyle]::Left
$titleLabel.Width = 320
$titleLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$titleLabel.Font = New-Object System.Drawing.Font("Microsoft YaHei", 10, [System.Drawing.FontStyle]::Bold)
$head.Controls.Add($titleLabel)

function New-HeadButton {
    param([string]$t)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $t
    $b.Width = 34
    $b.Height = 28
    $b.Dock = [System.Windows.Forms.DockStyle]::Right
    $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $b.FlatAppearance.BorderSize = 0
    $b.ForeColor = [System.Drawing.Color]::White
    $b.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
    $b.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    return $b
}

$btnClose = New-HeadButton "X"
$btnMin = New-HeadButton "_"
$btnAdd = New-HeadButton "+"
$btnPin = New-HeadButton "P"
$head.Controls.Add($btnClose)
$head.Controls.Add($btnMin)
$head.Controls.Add($btnAdd)
$head.Controls.Add($btnPin)

# ---- tray icon ----
$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon((Get-Process -Id $PID).Path)
$notify.Text = "Schedule Assistant - click to show / hide"
$notify.Visible = $true

$toggle = {
    if ($form.Visible) { $form.Hide() }
    else { $form.Show(); $form.Activate() }
}
$notify.Add_Click($toggle)

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miShow = $menu.Items.Add("Show / Hide")
$miShow.Add_Click($toggle)
$miPin = $menu.Items.Add("Always on top")
$miPin.Add_Click({ $form.TopMost = -not $form.TopMost })
$miReload = $menu.Items.Add("Reload")
$miReload.Add_Click({ $wb.Refresh() })
$addEventScript = {
    try {
        $txt = [Microsoft.VisualBasic.Interaction]::InputBox(
            "Type a natural-language schedule.`n`nExamples:`n  - tomorrow 10am meet John`n  - 周三下午3点评审会1小时`n  - Friday 2pm review",
            "Add schedule", "")
        if ($txt -and $txt.Trim().Length -gt 0) {
            $p = Start-Process -FilePath $pyExe -ArgumentList @("`"$scheduleTool`"","add","--text",$txt,"--force") -WorkingDirectory $workDir -Wait -WindowStyle Hidden -PassThru
            if ($p.ExitCode -eq 0) {
                $wb.Refresh()
            } else {
                [System.Windows.Forms.MessageBox]::Show("Add failed (exit=" + $p.ExitCode + ")", "Error", "OK", "Error") | Out-Null
            }
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Error: " + $_, "Error", "OK", "Error") | Out-Null
    }
}
$btnAdd.Add_Click($addEventScript)
$miAddM = $menu.Items.Add("Add event")
$miAddM.Add_Click($addEventScript)
$pyExe = "C:\Users\JLC\.workbuddy\binaries\python\versions\3.13.12\python.exe"
$updaterPy = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant\updater.py"
$workDir = "C:\Users\JLC\WorkBuddy\2026-09-05-17-00-34\schedule-assistant"
$miUpdate = $menu.Items.Add("Check for updates")
$miUpdate.Add_Click({
    Start-Process -FilePath $pyExe -ArgumentList "`"$updaterPy`"" -WorkingDirectory $workDir
})
$miExit = $menu.Items.Add("Exit")
$miExit.Add_Click({
    $script:reallyExit = $true
    $notify.Visible = $false
    $notify.Dispose()
    $form.Close()
})
$notify.ContextMenuStrip = $menu

$btnPin.Add_Click({ $form.TopMost = -not $form.TopMost })
$btnMin.Add_Click({ $form.Hide() })
$btnClose.Add_Click({ $form.Hide() })

# X button / Alt+F4 -> hide to tray instead of quitting
$form.Add_FormClosing({
    param($s, $e)
    if ($script:reallyExit) { return }
    $e.Cancel = $true
    $form.Hide()
})

[System.Windows.Forms.Application]::Run($form) | Out-Null
try { $notify.Dispose() } catch {}
